MySQL JDBC Users Example

1. Ensure MySQL is running and database `mydatabase` contains a `users`
   table with `id`, `username`, and `email` columns.
2. In MySQLJDBCUsers.java, change USERNAME and PASSWORD to your MySQL
   credentials. Replace `your_password` with your actual password.
3. Add MySQL Connector/J to your project's classpath.
4. Compile and run the Java program.

The program uses try-with-resources to close Connection, Statement, and
ResultSet automatically. It prints a readable error if the query fails.
